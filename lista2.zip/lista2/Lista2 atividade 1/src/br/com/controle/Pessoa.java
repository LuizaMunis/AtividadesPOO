
package br.com.controle;

public class Pessoa {
    
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String nome(){
    return this.nome;
    }
    
}
